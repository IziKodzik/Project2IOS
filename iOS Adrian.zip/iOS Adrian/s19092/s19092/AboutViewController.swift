//
//  AboutViewController.swift
//  s19092
//
//  Created by Aleksandra Knot on 16/01/2021.
//

import Foundation
import UIKit



class AboutViewController :UIViewController{
    @IBOutlet weak var korwinPhoto: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        korwinPhoto.layer.cornerRadius = 10
    }

    @IBAction func closePopup(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
}
