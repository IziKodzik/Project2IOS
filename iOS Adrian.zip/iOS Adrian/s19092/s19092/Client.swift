//
//  Client.swift
//  s19092
//
//  Created by Aleksandra Knot on 16/01/2021.
//

struct Client : Decodable{
    
    let id:Int
    let name:String
    let password:String
    let role:String
    let email:String
    
}
