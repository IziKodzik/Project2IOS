//
//  ViewController.swift
//  s19092
//
//  Created by Aleksandra Knot on 16/01/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "Menu"
    }


    @IBAction func aboutDidTap(_ sender: Any) {
    }
    @IBAction func usersListTap(_ sender: Any) {
//        [self.navigationController pushViewController:someNewViewController animated:YES];

    }
}

